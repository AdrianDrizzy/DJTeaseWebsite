<h1>MEGAPOD THEME</h1>

<p>MEGAPOD is a modern and trendy free music streaming website template</p>

<h2>Developed With<h2>
  <ul>
  <li>HTML</li>
  <li>CSS</li>
  <li>Bootstrap</li>
  </ul>
  <h1>Silent Features</h1>
  <ul>
  <li>Minimal,unique and dynamic design.</li>
  <li>Contains Unique CSS effects.</li>
  <li>A lot of sections are described in this template.</li>
  <li>Structured using pure CSS grid layout.</li>
  </ul>
  <h1>Project Preview:</h1>
(https://hamzaashfaq01.github.io/MegaPod/).
